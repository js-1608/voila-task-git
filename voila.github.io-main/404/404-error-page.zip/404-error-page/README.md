# 404 error page

A Pen created on CodePen.io. Original URL: [https://codepen.io/uiswarup/pen/dyoyLOp](https://codepen.io/uiswarup/pen/dyoyLOp).

404 error, SVG animation page, anime.js, Jharkhand,
error 404, Trending, Swarup Kumar Kuila, uiswarup, India